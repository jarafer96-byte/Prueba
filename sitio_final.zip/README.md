# Sitio generado automáticamente

Tipo de sitio: catálogo
Color: #0077cc
Fuente: Arial
Botones: redondeado
Contacto: sí
WhatsApp: sí
Pago: MercadoPago
